package dao;

public class Dao {

}
