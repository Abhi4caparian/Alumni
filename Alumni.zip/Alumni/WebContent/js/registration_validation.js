function formValidation(){
	
	var fname=document.register.fn;
	var lname=document.register.ln;
	var contact=document.register.tel;
	var address=document.register.add;
	var gen=document.register.gender;
	var emailid=document.register.email;
	var pass=document.register.pwd;
	var pass1=document.register.cmpwd;
	if(fname_validation(fname))
		{
		if(lname_validation(lname))
			{
			
				if(address_validation(address))
					{
					if(gen_validation(gen))
						{
						if(emailid_validation(emailid))
							{
							if(pass_validation(pass,7,12))
								{
								if(pass1_validation(pass1,7,12))
									{
									return true;
									}
								}
							}
						}
					}
				}
			}
		
	return false;
}
function fname_validation(fname)
{
var letter=/^[A-Za-z]+$/;
if(fname.value.match(letter))
	{
	return true;
	}
else
	{
	alert("First Name must be alphabetic");
	fname.focus();
	return false;
	}
}
function lname_validation(lname)
{
var letter=/^[A-Za-z]+$/;
if(lname.value.match(letter))
	{
	return true;
	}
else
	{
	alert("Last Name must be alphabetic");
	lname.focus();
	return false;
	}
}
function address_validation(address)
{
	var letter=/^[A-Za-z0-9_\.\ \-\&]+$/;
	if(address.value.match(letter))
		{
		return true;
		}
	else
		{
		alert("Please enter valid address");
	address.focus();
	return false;
		}
}
function gen_validation(gen)
{
if(gen.value=="default")
	{
alert("please enter gender from list");	
	gen.focus();
	return false;
	}
else
	{
	return true;
	}
}
function emailid_validation(emailid)
{
var letter=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
if(emailid.value.match(letter))
	{
	return true;
	}
else
	{
alert("Please enter valid emailid");
emailid.focus();
return false;
}
}
function pass_validation(pass,my,mx)
{
	var pass_len = pass.value.length;
	if(pass_len >= my && pass_len<=12)
		{
		return true;
		}
	else
		{
		alert("password length must be "+my+" to " +mx);
		pass.focus();
		return false;
		}

}
function pass_validation(pass1,my,mx)
{
var pass_len=pass1.value.length;
if(pass_len>=7 && pass_len<=12)
	{
	return true;
	}
else
	{
	alert("New password length must be "+my+" to "+mx);
	pass1.focus();
	return false;
	}

}


/*for login*/
function login_validate()
{
	var email=document.login.emailid;
	var pass=document.login.pass;
	
	if(email_val(emailid))
		{
		if(pass_val(pass,7,12))
			{
			return true;
			}
		}
	return false;
}

function email_val(emailid)
{
	var letter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if(emailid.value.match(letter))
		{
		return true;
		}
	else
		{
		alert("Please enter valid Email");
		emailid.focus();
		return false;
		}
	
}
function pass_validation(pass,my,mx)
{
	var pass_len = pass.value.length;
	if(pass_len >= mx && pass_len<=12)
		{
		return true;
		}
	else
		{
		alert("password length must be "+my+" to " +mx);
		pass.focus();
		return false;
		}
}
